<?php  include "includes/header.php";?>
<?php  include "includes/config.php";?>

<?php 

if(isset($_POST['submit'])){
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$username = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password'];	


$query ="INSERT INTO internal (firstname, lastname, username, email, password) VALUES ('$firstname', '$lastname', '$username', '$email', '$password')";
$query_run = mysqli_query($connection, $query);
if($query_run){
header("location:login.php");	
}
else{
	echo "Error!";
}


}

?>

<section style ="height:545px; width:100%;">
<center>
  <div style ="height:50px; background-color:lightblue; width:75%;" align ="center">

  
    <a href ="index.php" style ="background-color: lightblue;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Home</a>
  
  <a href ="login.php" style ="background-color: gray;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Login</a> 
  
  <a href ="register.php" style ="background-color: lightgreen;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Register</a></li>

  
    </ul>
  </div>
  </center>
  <br>
  <center>
  <fieldset style ="width:30%; border-radius:5px;">
  <form action ="" method ="post"> 
       <label for "firstname"></label><br>
	   <input type ="text" name ="firstname" placeholder ="Firstname" style ="border-radius:5px; height:25px;"></input><br>
	   
       <label for "lastname"></label><br>
	   <input type ="text" name ="lastname" placeholder ="Lastname" style ="border-radius:5px; height:25px;"></input><br>

       <label for "username"></label><br>
	   <input type ="text" name ="username" placeholder ="Username" style ="border-radius:5px; height:25px;"></input><br>	

       <label for "email"></label><br>
	   <input type ="email" name ="email" placeholder ="Email" style ="border-radius:5px; height:25px;"></input><br>	   
	   
	   <label for "password"></label><br>
	   <input type ="password" name ="password" placeholder ="Password" style ="border-radius:5px; height:25px;"></input><br>	

<br>
<button name ="submit" value ="Register">Register</button>	   
  </form>
  </fieldset>
  </center>

</section>

<?php  include "includes/footer.php";?>