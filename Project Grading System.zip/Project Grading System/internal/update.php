<?php
session_start();
if(!isset($_SESSION['username'])){
	
	echo "You are not logged in to see content";
	}else{
		$session =$_SESSION['username'];
		//echo "Welcome". $session."</br>";
		
	
}
?>

<?php
//include "includes/header.php";
include "includes/config.php";
$id =$_GET['id'];
echo $id."</br>";
if(isset($_POST['submit'])){
	$matric = $_POST['matric'];
	$appearance = $_POST['appearance'];
	$composure = $_POST['composure'];
	$presentation = $_POST['presentation'];
	$solution = $_POST['solution'];
	$method = $_POST['method'];
	$total = $appearance + $composure + $presentation + $solution + $method;
	$examiner = $session;
	
	$query ="UPDATE internal_grading SET matric ='$matric', appearance ='$appearance', composure ='$composure', 
	presentation ='$presentation', solution_proffering ='$solution', method ='$method', total ='$total', examiner ='$session' where id ='$id'";
	$query_run = mysqli_query($connection, $query);
	
	if($query_run){
		echo"Update Done";
		
	}else{
		echo"Sorry there was an error";
	}
	
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
         .wrapper{
            width: 500px;
            margin: 0 auto;
        }
body {background:  url("images/background.png");
      background-repeat:no-repeat;
      background-size:160%;
      color: ;
      font-size: 14px;
      font-size: 14px;
      font-family: Cambria;
      margin: 0;
      padding: 0;
      text-align: center;} /* Needed to center layout in old IE browsers. */
}
 .wrapper{
            width: 650px;
            margin: 0 auto;
        }
        .page-header h2{
            margin-top: 0;
        }
        table tr td:last-child a{
            margin-right: 15px;
        }
    </style>
</head>
<center>
<body>
    
                    <p>Please edit the input values and submit to update the record.</p>
					<center>
                    <fieldset style ="background:gray; height:; width:30%; border-radius:15px;">
    <form action = "" method ="post">
	<label for "matric"></label><br>
	<input name ="matric" type ="text" style ="height:30px; width:190px; border-radius:5px;  text-border:1px solid brown;" placeholder ="Matric number of Student"></input><br>
	
	<label for "appearance"></label><br>
	<input name ="appearance" type ="text" style ="height:30px; width:190px; border-radius:5px;  text-border:1px solid brown;" placeholder ="Appearance"></input><br>
	
	<label for "composure"></label><br>
	<input name ="composure" type ="text" style ="height:30px; width:190px; border-radius:5px;  text-border:1px solid brown;" placeholder ="Composure"></input><br>
	
	<label for "presentation"></label><br>
	<input name ="presentation" type ="text" style ="height:30px; width:190px; border-radius:5px;  text-border:1px solid brown;" placeholder ="Presentation"></input><br>
	
	<label for "solution"></label><br>
	<input name ="solution" type ="text" style ="hheight:30px; width:190px; border-radius:5px;  text-border:1px solid brown;" placeholder ="Solution Proffering"></input><br>
	
	<label for "method"></label><br>
	<input name ="method" type ="text" style ="height:30px; width:190px; border-radius:5px;  text-border:1px solid brown;" placeholder ="Method of Data Gathering"></input><br>
	

	
	
	<br>
	<button name = "submit" type ="submit">Submit</button>
	<button><a href ="dashboard.php">Cancel</a></button>
	</form>
	</fieldset>
	<button><a href="dashboard.php">Back</a></button>
					</center>
                
</body>
</center>
</html>
<?php //include "includes/footer.php";?>