<?php
include "includes/header.php";
$id = $_GET['id'];
echo "$id";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
         .wrapper{
            width: 500px;
            margin: 0 auto;
        }
body {background:  url("images/background.png");
      background-repeat:no-repeat;
      background-size:160%;
      color: ;
      font-size: 14px;
      font-size: 14px;
      font-family: Cambria;
      margin: 0;
      padding: 0;
      text-align: center;} /* Needed to center layout in old IE browsers. */
}
 .wrapper{
            width: 650px;
            margin: 0 auto;
        }
        .page-header h2{
            margin-top: 0;
        }
        table tr td:last-child a{
            margin-right: 15px;
        }
    </style>
</head>

</html>
<?php include "includes/footer.php";?>