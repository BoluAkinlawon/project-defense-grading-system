<?php
// Include config file

  
  

?>
<?php
session_start();
if(!isset($_SESSION['username'])){
	
	echo "You are not logged in to see content";
	}else{
		$session =$_SESSION['username'];
		//echo "Welcome". $session."</br>";
		
	
}
?>

<?php 
include "includes/config.php";
if(isset($_POST['submit'])){
	$matric = $_POST['matric'];
	$appearance = $_POST['appearance'];
	$composure = $_POST['composure'];
	$presentation = $_POST['presentation'];
	$solution = $_POST['solution'];
	$method = $_POST['method'];
	$total = $appearance + $composure + $presentation + $solution + $method;
	$examiner = $session;
	
	$query = "INSERT INTO external_grading(matric, appearance, composure, presentation, solution_proffering, method, total, examiner) VALUES('$matric', '$appearance', '$composure', '$presentation', '$solution', '$method', '$total', '$examiner')";
	$query_run = mysqli_query($connection, $query);
	
	if($query_run){
		echo"Success";
		
	}else{
		echo"Sorry there was an error";
	}
	
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
       body {background:  url("images/background.png");
      background-repeat:no-repeat;
      background-size:160%;
      color: ;
      font-size: 12px;
      font-size: 12px;
      font-family: Cambria;
      margin: 0;
      padding: 0;
      text-align: center;} /* Needed to center layout in old IE browsers. */
	  
	  /* Media Queries: Tablet Landscape */
@media screen and (max-width: 1060px) {
    #primary { width:67%; }
    #secondary { width:30%; margin-left:3%;}  
}

/* Media Queries: Tabled Portrait */
@media screen and (max-width: 768px) {
    #primary { width:100%; }
    #secondary { width:100%; margin:0; border:none; }
}

 #leftbox { 
                float:left;  
                background:lightblue; 
                width:50%; 
                height:130px;
				
                			
            } 
             
            #rightbox{ 
                float:right; 
                background:cyan; 
                width:50%; 
                height:130px;
                				
            } 
            h1{ 
                color:green; 
                text-align:center; 
            } 
			

* {box-sizing: border-box;}
body {font-family: Verdana, sans-serif;}
.mySlides {display: none;}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
  height: 400px;
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .text {font-size: 11px}
}

    </style>
</head>
<center>
<body>
   
                        <h2>Create new Student Record</h2>
                    </div>
                    <p>Please fill this form and submit to add student record to the database.</p>
                    <fieldset style ="background:gray; height:; width:30%; border-radius:15px;">
    <form action = "" method ="post">
	<label for "matric"></label><br>
	<input name ="matric" type ="text" style ="height:30px; width:190px; border-radius:5px;  text-border:1px solid brown;" placeholder ="Matric number of Student"></input><br>
	
	<label for "appearance"></label><br>
	<input name ="appearance" type ="text" style ="height:30px; width:190px; border-radius:5px;  text-border:1px solid brown;" placeholder ="Appearance"></input><br>
	
	<label for "composure"></label><br>
	<input name ="composure" type ="text" style ="height:30px; width:190px; border-radius:5px;  text-border:1px solid brown;" placeholder ="Composure"></input><br>
	
	<label for "presentation"></label><br>
	<input name ="presentation" type ="text" style ="height:30px; width:190px; border-radius:5px;  text-border:1px solid brown;" placeholder ="Presentation"></input><br>
	
	<label for "solution"></label><br>
	<input name ="solution" type ="text" style ="hheight:30px; width:190px; border-radius:5px;  text-border:1px solid brown;" placeholder ="Solution Proffering"></input><br>
	
	<label for "method"></label><br>
	<input name ="method" type ="text" style ="height:30px; width:190px; border-radius:5px;  text-border:1px solid brown;" placeholder ="Method of Data Gathering"></input><br>
	

	
	
	<br>
	<button name = "submit">Submit</button>
	<button><a href ="dashboard.php">Cancel</a></button>
	</form>
		<button><a href ="dashboard.php">Back</a></button>
	</fieldset>
               
</body>
</center>
</html>