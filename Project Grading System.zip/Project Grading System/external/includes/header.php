<html>

<head>
<title>Project Grading System</title>
<meta content="text/html; charset=ISO-8859-1" http-equiv="content-type" />
<meta name="viewport" content="width=100% height =100%,initial-scale=0.7,maximum-scale=1.0,user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="HandheldFriendly" content="true">

<link rel="stylesheet" href="style.css" type="text/css" />
<link rel="shortcut icon" href="images/logo.ico" />
<style>
body {background:  url("../images/background.png");
      background-repeat:no-repeat;
      background-size:160%;
      color: ;
      font-size: 14px;
      font-size: 14px;
      font-family: Cambria;
      margin: 0;
      padding: 0;
      text-align: center;} /* Needed to center layout in old IE browsers. */
	  
	  /* Media Queries: Tablet Landscape */
@media screen and (max-width: 1060px) {
    #primary { width:67%; }
    #secondary { width:30%; margin-left:3%;}  
}

/* Media Queries: Tabled Portrait */
@media screen and (max-width: 768px) {
    #primary { width:100%; }
    #secondary { width:100%; margin:0; border:none; }
}

 #leftbox { 
                float:left;  
                background:lightblue; 
                width:50%; 
                height:130px;
				
                			
            } 
             
            #rightbox{ 
                float:right; 
                background:cyan; 
                width:50%; 
                height:130px;
                				
            } 
            h1{ 
                color:green; 
                text-align:center; 
            } 
			

</style>
</head>
<body>
<hr>
<center>

</center>
<br>


<hr>
</body>
</html>