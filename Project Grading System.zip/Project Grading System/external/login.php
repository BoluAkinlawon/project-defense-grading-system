<?php  include "includes/header.php";?>
<?php  include "includes/config.php";?>

<?php
if (isset($_POST['submit'])){
	$username =$_POST['username'];
	$password =$_POST['password'];
	
	$query= "SELECT username, password from external where username ='$username'and password ='$password'";
	$query_run=mysqli_query($connection,$query);
	
	if ($query_run -> num_rows > 0){
		session_start();
		$_SESSION['username'] = $username;
		header("location:dashboard.php");
		
	}else{
		echo "<p align =center>"."Sorry you have to register first";
		//header("location:register.php");
	}
	
}
?>

<section style ="height:545px; width:100%;">
<center>
  <div style ="height:35px; background-color:lightblue; width:50%;" align ="center">

  
  <a href ="../index.php" style ="background-color: lightblue;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Home</a>
  
  <a href ="login.php" style ="background-color: gray;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Login</a> 
  
  <a href ="register.php" style ="background-color: lightgreen;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Register</a></li>
  
    </ul>
  </div>
  </center>

<br>
<center>
  <fieldset style ="width:30%; border-radius:5px;">
  <form action ="" method ="post"> 
       <label for "firstname"></label><br>
	   <input type ="text" name ="username" placeholder ="Username" style ="border-radius:5px; height:25px;"></input><br>	

   
	   <label for "firstname"></label><br>
	   <input type ="password" name ="password" placeholder ="Password" style ="border-radius:5px; height:25px;"></input><br>	

<br>
<button name ="submit" name ="Login">Log In</button>	   
  </form>
  </fieldset>
  </center>
</section>

<?php  include "includes/footer.php";?>