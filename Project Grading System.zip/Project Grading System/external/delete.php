
<?php
include "includes/config.php";
if(isset($_POST['submit'])){
	
	$id = $_GET['id'];
	echo $id."</br>";
	$query ="DELETE FROM external_grading where id ='$id'";
	$query_run = mysqli_query($connection, $query);
	
	if($query_run){
		echo "Deleted Successfully"."</br>";
		
	}else{
		echo "error";
	}
	
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
body {background:  url("images/background.png");
      background-repeat:no-repeat;
      background-size:160%;
      color: ;
      font-size: 14px;
      font-size: 14px;
      font-family: Cambria;
      margin: 0;
      padding: 0;
      text-align: center;} /* Needed to center layout in old IE browsers. */
}
 .wrapper{
            width: 650px;
            margin: 0 auto;
        }
        .page-header h2{
            margin-top: 0;
        }
        table tr td:last-child a{
            margin-right: 15px;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h1>Delete Record</h1>
                    </div>
                    <form action="" method="post">
                        <div class="alert alert-danger fade in">
                            <input type="hidden" name="id" value=""/>
                            <p>Are you sure you want to delete this record?</p><br>
                            <p>
                                <input type="submit" name ="submit" value="Yes" class="btn btn-danger">
                                <a href="dashboard.php" class="btn btn-default">No</a>
                            </p>
                        </div>
                    </form>
					<button><a href="dashboard.php">Back</a></button>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>