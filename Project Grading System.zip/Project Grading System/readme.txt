create a database "defense"
Import the defense.sql file into it

For admin section;
Username = admin
password = admin