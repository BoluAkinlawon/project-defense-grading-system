<?php  include "includes/header.php";?>
<?php
session_start();
if(!isset($_SESSION['username'])){
	
	header("location:login.php");
	}else{
		$session =$_SESSION['username'];
		//echo "Welcome". $session."</br>";
		
	
}
?>
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
<style>
.wrapper{
            width: 500px;
            margin: 0 auto;
        }
body {background:  url("images/background.png");
      background-repeat:no-repeat;
      background-size:180%;
      color: ;
      font-size: 14px;
      font-size: 14px;
      font-family: Cambria;
      margin: 0;
      padding: 0;
      text-align: center;} /* Needed to center layout in old IE browsers. */
}
 .wrapper{
            width: 650px;
            margin: 0 auto;
        }
        .page-header h2{
            margin-top: 0;
        }
        table tr td:last-child a{
            margin-right: 15px;
        }
</style>

<script type="text/javascript">
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();   
        });
    </script>

</head>
<body >
<section style ="height:545px; width:100%;">
<center>

  <a href ="../index.php" style ="background-color: lightblue;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Home</a>
  
  <a href ="login.php" style ="background-color: gray;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Login</a> 
  
  <a href ="register.php" style ="background-color: lightgreen;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Register</a>
  
  <?php
    if(isset($_POST['logout'])){
		session_destroy();
		header("location:login.php");
		
	}
  
  ?>
  <br>
  <a><form method ="post">
  <button type ="submit" name ="logout" style ="background-color: gray;
  color: white;padding: 10px 15px; text-align: center;text-decoration: none;
  display: inline-block; border-radius:5px;">Log Out</button> 
  </form>
  </a>
  </li>
    </ul>
  </div>
  </center>

    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header clearfix">
                        <h2 class="pull-left">Gradings</h2>
                      
                    </div>
                    <?php
                    // Include config file
                    require_once "includes/config.php";
                    
                    // Attempt select query execution
                    $sql = "SELECT internal.id, internal.matric, internal.appearance, internal.composure, internal.presentation, internal.solution_proffering, internal.method,  internal.examiner, internal.total, external.matric, 
					       external.appearance, external.composure, external.presentation, external.solution_proffering, external.method, external.examiner, external.total FROM internal_grading internal join external_grading external
						   on (internal.matric = external.matric)";
                    if($result = mysqli_query($connection, $sql)){
                        if(mysqli_num_rows($result) > 0){
                            echo "<table class='table table-bordered table-striped'>";
                                echo "<thead>";
                                    echo "<tr>";
                                        echo "<th>#</th>";
                                        echo "<th>Matric Number</th>";
										echo "<th>Appearance(internal)</th>";
										echo "<th>Composure</th>";
                                        echo "<th>Presentation</th>";
                                        echo "<th>Solution Proffering</th>";
										echo "<th>Method of data Gathering</th>";
										echo "<th>Internal Examiner</th>";
										echo "<th>Total</th>";
										
										echo "<th>Matric(external)</th>";
										echo "<th>Appearance(external)</th>";
										echo "<th>Composure</th>";
                                        echo "<th>Presentation</th>";
                                        echo "<th>Solution Proffering</th>";
										echo "<th>Method of data Gathering</th>";
										
										echo "<th>External Examiner</th>";
										echo "<th>Total</th>";
										
                                        
                                    echo "</tr>";
                                echo "</thead>";
                                echo "<tbody>";
                                while($row = mysqli_fetch_array($result)){
                                    echo "<tr>";
                                        echo "<td>" . $row['id'] . "</td>";
                                        echo "<td>" . $row['matric'] . "</td>";
                                         echo "<td>" . $row['appearance'] . "</td>";
										  echo "<td>" . $row['composure'] . "</td>";
										   echo "<td>" . $row['presentation'] . "</td>";
										    echo "<td>" . $row['solution_proffering'] . "</td>";
											echo "<td>" . $row['method'] . "</td>";
											echo "<td>" . $row['examiner'] . "</td>";
											echo "<td>" . $row['total'] . "</td>";
											
											echo "<td>" . $row['matric'] . "</td>";
											      echo "<td>" . $row['appearance'] . "</td>";
										  echo "<td>" . $row['composure'] . "</td>";
										   echo "<td>" . $row['presentation'] . "</td>";
										    echo "<td>" . $row['solution_proffering'] . "</td>";
											echo "<td>" . $row['method'] . "</td>";
											echo "<td>" . $row['examiner'] . "</td>";
											echo "<td>" . $row['total'] . "</td>";
											
											
										  
                                        echo "<td>";
                                            echo "<a href='read.php?id=". $row['id'] ."' title='View Record' data-toggle='tooltip'><span class='glyphicon glyphicon-eye-open'></span></a>";
                                            echo "<a href='update.php?id=". $row['id'] ."' title='Update Record' data-toggle='tooltip'><span class='glyphicon glyphicon-pencil'></span></a>";
                                            echo "<a href='delete.php?id=". $row['id'] ."' title='Delete Record' data-toggle='tooltip'><span class='glyphicon glyphicon-trash'></span></a>";
                                        echo "</td>";
                                    echo "</tr>";
                                }
                                echo "</tbody>";                            
                            echo "</table>";
                            // Free result set
                            mysqli_free_result($result);
                        } else{
                            echo "<p class='lead'><em>No records were found.</em></p>";
                        }
                    } else{
                        echo "ERROR: Could not able to execute $sql. " . mysqli_error($connection);
                    }
 
                    // Close connection
                    mysqli_close($connection);
                    ?>
                </div>
            </div>        
        </div>
    </div>
</section>
</body>

<?php  include "includes/footer.php";?>