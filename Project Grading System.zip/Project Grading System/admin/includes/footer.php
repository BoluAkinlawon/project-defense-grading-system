<html>
<body>
   <center>
        <div style ="background:lightblue; height:60px; width:80%;">
   <center>
</body>
</html>